<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://necolas.github.io/normalize.css/8.0.1/normalize.css">
    <link rel="stylesheet" href="style.css">
<!-- Подключение стилей -->
    <title>Админ</title>
</head>
<body>
    <div class="header"><h1>Записываемся на ноготочки</h1>
    <p class="p1"> <a href="index.php">  Выйти</a> <a href="oreder.php"> Заявки</a> <a href="zayava.php"> Бронирование</a></p>
   <!-- Кнопки перемещения -->
    </div> 
    <!-- Заголовок -->
    <div class="footnotead">
        <center><H3>Войти как Админ</H3></center>
    <form method="POST">
    <div class="adlog">
        <input type="text" id="adlog" name="adlog" placeholder="Логин">
        </div>
        <div class="pass">
        <input type="password" id="adlog" name="adpass" placeholder="Пароль">
        </div>
    <!-- Строки ввода данных -->
    <div class="but"><button> Войти</button>
    </div>
</div>
</form>
     
</body>
</html>